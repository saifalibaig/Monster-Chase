using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterSpawner : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField]
    private GameObject[] monsterReference; // to make copies of the monsters
    [SerializeField]
    private Transform leftpos, rightpos;

    private GameObject spawnedMonster;
    private int randomSide; // to randomise the direction in which it is spawned 
    private int randomIndex; // to randomise which monster is spawned
    private int n = 0;          


    void Start()
    {
        StartCoroutine(SpawnMonsters());
    }

   
    // create a coroutine as we can call it over and over again on a set time interval 
    IEnumerator SpawnMonsters()
    {
        yield return new WaitForSeconds(Random.Range(1, 5)); // randomly choses the time interval that we have to wait before a new monster is spawned 
        randomIndex = Random.Range(0,monsterReference.Length);  // randomly choses the monster ( value between 0 and 3 )
        randomSide = Random.Range(0, 2);
    
        spawnedMonster = Instantiate(monsterReference[randomIndex]);
       while (n < 5)
        {
            if (randomSide == 0)
            {

                spawnedMonster.transform.position = leftpos.position;
                spawnedMonster.GetComponent<Monster>().speed = Random.Range(4, 10);

            }
            else
            {

                spawnedMonster.transform.position = rightpos.position;
                spawnedMonster.GetComponent<Monster>().speed = -Random.Range(4, 10); // negative sign as we wanna change the direction of movement of the monster
                spawnedMonster.transform.localScale = new Vector3(-1f, 1f, 1f);
            }
            n++;

        }

    }

}
