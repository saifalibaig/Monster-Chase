using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    // Start is called before the first frame update
    private Transform player;
    private Vector3 tempPos;
    private string PlayerTag = "Player";
    [SerializeField]
    private float maxX, minX;
    

    void Start()
    {
        player = GameObject.FindWithTag(PlayerTag).transform;
    }

    // Update is called once per frame
    void LateUpdate() // done after all calc in update are finished 
    {
        if (player == null)
        {
            return;
        }
        tempPos = transform.position;
        tempPos.x = player.position.x;

        if (tempPos.x < minX)
        {
            tempPos.x = minX;
        }
        if (tempPos.x > maxX)
        {
            tempPos.x = maxX;
        }
        transform.position = tempPos;
        
    }
}
