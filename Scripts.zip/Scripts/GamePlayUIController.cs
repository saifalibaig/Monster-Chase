using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GamePlayUIController : MonoBehaviour
{
    // Start is called before the first frame update
    public void restart()
    {
        //SceneManager.LoadScene("Gameplay");
        SceneManager.LoadScene(SceneManager.GetActiveScene().name); // returns us the name of the scene we r on so we can easily open it


    }
    public void homeButton()
    {
        SceneManager.LoadScene("MainMenu");

    }
}
