using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField]
    private float moveForce = 10f;
    [SerializeField]
    public float jumpForce = 11f;

    private float moveX;
    private bool isGrounded = true;
    private Rigidbody2D mybody;
    private SpriteRenderer sr;
    private Animator anim;
    private string WALK_ANIMATION = "Walk";
    private string GROUND_TAG = "Ground";
    private string ENEMY_TAG = "Enemy";

    private void Awake()
    {
        mybody=GetComponent<Rigidbody2D>(); // to add physics to your character
        sr = GetComponent<SpriteRenderer>(); // to flip the direction of the character 
        anim = GetComponent<Animator>(); // to animate the movement of the player



    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        PlayerMoveKeyboard();
        AnimatePlayer();
    }

    private void FixedUpdate() // after fixed no of intervals of frame
    {
        PlayerJump();
    }

    void PlayerMoveKeyboard()
    {
        moveX = Input.GetAxisRaw("Horizontal"); // left arrow or A = -1, no touch = 0 , right arrrow or d = 1
        transform.position += new Vector3(moveX, 0f, 0f) * Time.deltaTime * moveForce;

    }

    void AnimatePlayer()
    {
        if (moveX > 0)
        {
            anim.SetBool(WALK_ANIMATION,true);
            sr.flipX  = false;
        }
        else if (moveX < 0)
        {
            anim.SetBool(WALK_ANIMATION, true);
            sr.flipX = true;

        }
        else
        {
            anim.SetBool(WALK_ANIMATION, false);
            sr.flipX= false;
        }
    }

    void PlayerJump()
    {
        // Input.GetButton("Jump) -> true when button held
        // Input.GetButtonUp("Jump) -> true when button released
        // Input.GetButtonDown("Jump) -> true when button pressed
        if (Input.GetButtonDown("Jump") && isGrounded ){
            mybody.AddForce(new Vector2(0f, jumpForce), ForceMode2D.Impulse);
            isGrounded = false;
            
        }
    }
    // ForceMode2D.Impulse to move it instantly

    private void OnCollisionEnter2D(Collision2D collision) // detect collision between two game objects
    {
        if (collision.gameObject.CompareTag(GROUND_TAG))
        {
            isGrounded = true;
        }
        if (collision.gameObject.CompareTag(ENEMY_TAG))
        {
            Destroy(gameObject);
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)  // tick the istrigger in rigid body for it to work
    {
        if (collision.CompareTag(ENEMY_TAG))
            {
                Destroy(gameObject);
            }
    }
}
