using System.Collections;
using System.Collections.Generic;
using UnityEditor.SearchService;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{

    public static GameManager Instance;
    // Start is called before the first frame update
    [SerializeField]
    private GameObject[] characters;

    private int _charIndex;
    public int CharIndex
    {
        get { return _charIndex; }  
        set { _charIndex = value; } 
    }

    private void Awake()
    {
        //singleton pattern / 1 copy of the game objext

        if(Instance == null)
        {
            Instance = this; 
            DontDestroyOnLoad(gameObject); // as we transition from scene to scene the data/ objects are destroyes, in order to maintain the data we use this

        }
        else
        {
            Destroy(gameObject);
        }
    }

    // to load our character we need to use events and delegates
    void OnLevelFinishedLoading(UnityEngine.SceneManagement.Scene scene , LoadSceneMode mode)
    {
        if (scene.name == "Gameplay")
        {
            Instantiate(characters[CharIndex]);
        }
    }

    private void OnEnable()
    {
        SceneManager.sceneLoaded += OnLevelFinishedLoading;
    }

    private void OnDisable()
    {

        SceneManager.sceneLoaded -= OnLevelFinishedLoading;
    }

}
