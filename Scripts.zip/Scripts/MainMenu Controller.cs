using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; // for switching between scenes


public class MainMenuController : MonoBehaviour
{
    //button ka code

    public void PlayGame()
    {
        // to get the name of the UI element that was pressed 
        int selectedCharacter =
            int.Parse(UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject.name);

        GameManager.Instance.CharIndex = selectedCharacter; 
       
        SceneManager.LoadScene("Gameplay");
      
    } 
}
